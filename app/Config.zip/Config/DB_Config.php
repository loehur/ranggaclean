<?php

class DB_Config
{
    public $db_host = 'localhost';
    public $db_user = 'root';
    public $db_pass = '';
    public $db_name = 'laundry';

    // public $db_host = 'b1sm0doksfrkeqznptf9-mysql.services.clever-cloud.com:3306';
    // public $db_user = 'uqmrebtlwu2q4iz4';
    // public $db_pass = 'VjFGvb8ShqTNOXOfK6MW';
    // public $db_name = 'b1sm0doksfrkeqznptf9';

    // public $db_host = '34.128.127.99';
    // public $db_user = 'luhur';
    // public $db_pass = 'a123654b';
    // public $db_name = 'laundry';


    public $NoSQL_url = "https://mdl-laundry-default-rtdb.asia-southeast1.firebasedatabase.app/";
}
