<?php

class URL
{
    public $BASE_URL = '/web/laundry/';
    public $ASSETS_URL = '/web/laundry/assets/';
}
