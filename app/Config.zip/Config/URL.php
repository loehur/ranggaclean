<?php

class URL
{
    public $BASE_URL = '/web/cleaningklin.com/';
    public $ASSETS_URL = '/web/cleaningklin.com/assets/';
}
